#pragma once

// The GS drawn on the graphics card (paraLLEl-GS, Vulkan compute), next to the CPU renderer.
// This header carries no Vulkan / Granite types: only gs_gpu_parallel.cpp sees the library.
//
// PS2X_GS=gpu   (default) the graphics card draws everything; nothing is drawn on the CPU (reads of GS memory are
//                   answered by the graphics card). Without a usable Vulkan device: the CPU renderer, as with cpu.
// PS2X_GS=cpu   the CPU renderer alone
// PS2X_GS=both  both draw: the CPU renderer answers the reads; the window shows the graphics card's picture
//                   (PS2X_GS_SHOW=cpu: the CPU renderer's, for comparing)
//
// PS2X_SSAA=1|2|4|8|16 (default 8)      samples per pixel (super-sampling)
// PS2X_SSAA_ORDERED=0|1 (default 1)     ordered or rotated sample grid
// PS2X_SSAA_TEXTURES=0|1 (default 0)    render targets used as textures keep their samples
// PS2X_HIRES=0|1 (default 1)            a double-resolution picture from the samples (needs SSAA >= 4)
// PS2X_GPU=<index or name substring>    which Vulkan device (default: the library's choice, a discrete GPU first)
// PS2X_FILTER=fsr|bilinear|nearest      how the picture is scaled to the window (default fsr on the graphics card:
//                                           AMD FSR 1 upscaling + RCAS sharpening at the window's size; bilinear on the CPU)
// PS2X_SHARPEN=<0..2> (default 0.5)     FSR's sharpening: 0 = sharpest, each 1 halves it
// PS2X_GPU_LOG=1                        the library's own information lines (devices, extensions)
// PS2X_GPU_SYNC=1                       wait for the graphics card thread after every call (debugging)
// PS2X_GPU_VERIFY=1[,N]                 (with PS2X_GS=both) compare GS memory and the picture every N presentations
//                                           (default 60); PS2X_GPU_VERIFY_DUMP=<dir> saves the first 3 differing pairs

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

enum class GSRendererMode : uint8_t
{
    Cpu,
    Gpu,
    Both,
    Null, // [gta-recomp] PS2X_GS=null: discard all GS work (profiling the rest of the frame)
};

// How the picture is scaled to the window. Fsr = on the graphics card (its picture only; else Bilinear).
enum class GSPresentFilter : uint8_t
{
    Nearest,
    Bilinear,
    Fsr,
};

GSRendererMode gsRendererModeFromEnvironment();
GSPresentFilter gsPresentFilterFromEnvironment();
const char *gsRendererModeName(GSRendererMode mode);

struct GSGpuOptions
{
    uint32_t superSampling = 8; // 1, 2, 4, 8 or 16
    bool orderedGrid = true;
    bool superSampledTextures = false;
    bool highResolutionScanout = true;
    bool fsr = true;
    float sharpness = 0.5f;
    bool libraryLog = false;
    bool sync = false;
    size_t ringBytes = size_t{16} << 20u;
    std::string gpuSelector;

    static GSGpuOptions fromEnvironment();
};

// One finished picture, read back from the graphics card. 0 × 0 = nothing displayed (black).
struct GSGpuFrame
{
    uint64_t seq = 0;
    uint32_t width = 0;
    uint32_t height = 0;
    // For the aspect ratio: the part of the video mode the picture covers, in single-sample pixels.
    uint32_t internalWidth = 0;
    uint32_t internalHeight = 0;
    uint32_t modeWidth = 0;
    uint32_t modeHeight = 0;
    bool highResolution = false;
    std::vector<uint8_t> rgba;
    // Shown straight from the graphics card (PS2X_PRESENT=vulkan): the picture is in shared image sharedImage
    // (R8G8B8A8, width x height) of the current set (Windows handles sharedHandles, made again when sharedGeneration
    // changes), finished once the shared timeline semaphore (sharedTimeline) reaches seq; rgba stays empty. The
    // device's UUID (sharedDeviceUuid): the window's device must be on the same graphics card.
    bool shared = false;
    int sharedImage = -1;
    uint64_t sharedGeneration = 0;
    void *sharedHandles[4] = {};
    void *sharedTimeline = nullptr;
    uint8_t sharedDeviceUuid[16] = {};
};

// What the graphics card renderer is doing (the debug panel's Graphics tab).
struct GSGpuStatus
{
    uint32_t superSampling = 0;
    bool highResolution = false;
    bool fsr = false;
    float sharpness = 0.0f;
    uint32_t pictureWidth = 0; // the last picture read back
    uint32_t pictureHeight = 0;
    float busyPercent = 0.0f; // the graphics card thread, over the last second
    float presentsPerSecond = 0.0f;
    float gifMegabytesPerSecond = 0.0f;
    float renderPassesPerSecond = 0.0f;
};

// A lock-free triple buffer: one writer (the graphics card thread), one reader (the main thread).
class GSGpuFrameMailbox
{
public:
    GSGpuFrame &writeSlot() noexcept { return m_slot[m_back]; }
    void publish() noexcept
    {
        m_back = m_middle.exchange(m_back | kFresh, std::memory_order_acq_rel) & kIndexMask;
    }
    // The newest published frame if it is newer than lastSeq, else null.
    const GSGpuFrame *take(uint64_t &lastSeq) noexcept
    {
        if ((m_middle.load(std::memory_order_acquire) & kFresh) != 0u)
            m_front = m_middle.exchange(m_front, std::memory_order_acq_rel) & kIndexMask;
        const GSGpuFrame &frame = m_slot[m_front];
        if (frame.seq == 0u || frame.seq == lastSeq)
            return nullptr;
        lastSeq = frame.seq;
        return &frame;
    }

    // The shared image the reader is drawing from (-1: none): the writer never draws into it. Set by the reader
    // before it uses a taken frame's image, cleared once its graphics card work on it is done.
    std::atomic<int> sharedReading{-1};

private:
    static constexpr uint32_t kFresh = 4u;
    static constexpr uint32_t kIndexMask = 3u;
    GSGpuFrame m_slot[3];
    std::atomic<uint32_t> m_middle{1u};
    uint32_t m_back = 0u;  // writer only
    uint32_t m_front = 2u; // reader only
};

class GSGpuRenderer
{
public:
    static constexpr uint32_t kPrivRegCount = 15; // PMODE … BGCOLOR, in GS register order

    virtual ~GSGpuRenderer() = default;

    virtual const char *deviceName() const = 0;

    // The producer (whoever holds the GS front end's state lock), in the front end's order: the raw GS input.
    virtual void gif(uint8_t path, const uint8_t *data, uint32_t bytes) = 0; // whole quadwords
    virtual void reg(uint8_t addr, uint64_t value) = 0;
    virtual void reset() = 0;
    virtual void present(const uint64_t (&privRegs)[kPrivRegCount], uint64_t vsyncTick, bool flip) = 0;
    virtual void kick() = 0;
    // The producer, blocking: answered after everything sent before (GS memory as of this point in the order).
    virtual void snapshotVram(std::vector<uint8_t> &out) = 0;              // all 4 MiB
    virtual uint32_t readTransfer(uint8_t *dst, uint32_t maxBytes) = 0;    // a local -> host transfer's data

    // The game thread, holding no lock: wait while more than maxAhead presentations are not yet drawn.
    virtual bool waitPresentBacklog(uint32_t maxAhead, const std::atomic<bool> &stop) = 0;
    virtual void wake() = 0;

    // The main thread: the newest finished picture if newer than lastSeq, else null (valid until the next take).
    virtual const GSGpuFrame *takeFrame(uint64_t &lastSeq) = 0;
    // The main thread: the size the picture is shown at (FSR draws at exactly that size).
    virtual void setOutputSize(uint32_t width, uint32_t height) = 0;
    // The main thread, with shared pictures: the shared image it is drawing from (-1 when done with it).
    virtual void setSharedReading(int image) { (void)image; }

    // Any thread: live settings, taken at the next presentation.
    virtual void setSuperSampling(uint32_t rate) = 0; // 1, 2, 4, 8 or 16
    virtual void setHighResolution(bool on) = 0;
    virtual void setFsr(bool on) = 0;
    virtual void setSharpness(float stops) = 0;
    virtual GSGpuStatus status() const = 0;

    // Idempotent; joins the renderer's thread, which owns (and destroys) every Vulkan object.
    virtual void shutdown() = 0;
};

// nullptr when this build has no paraLLEl-GS or the device could not be set up; whyNot says which.
std::unique_ptr<GSGpuRenderer> makeGpuRenderer(const GSGpuOptions &options, std::string &whyNot);
std::unique_ptr<GSGpuRenderer> makeNullGpuRenderer(); // [gta-recomp]
